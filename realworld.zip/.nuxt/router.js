import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b1982500 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _daa2f696 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _794b4b5a = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _2f53e213 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _4c6870f9 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _c935d87a = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _161e2560 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _b1982500,
    children: [{
      path: "",
      component: _daa2f696,
      name: "home"
    }, {
      path: "/login",
      component: _794b4b5a,
      name: "login"
    }, {
      path: "/register",
      component: _794b4b5a,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _2f53e213,
      name: "profile"
    }, {
      path: "/settings",
      component: _4c6870f9,
      name: "settings"
    }, {
      path: "/editor",
      component: _c935d87a,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _161e2560,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
